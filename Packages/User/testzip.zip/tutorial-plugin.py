import sublime
import sublime_plugin
import re
import os
import zipfile
import tempfile

import webbrowser

def GetCString(view, region):
	startIndex = region.begin()
	endIndex = region.end()
	viewSize = view.size()
	
	if (startIndex == 0):
		return "";
	
	# Step back till we find the (non-escaped) quotation mark or the beginning of line/file
	currentChar = view.substr(startIndex-1)
	while (startIndex > 0):
		if (currentChar == '\"' and (startIndex <= 0 or view.substr(startIndex-2) != "\\")):
			break
		if (currentChar == '\n' or currentChar == '\r'):
			# startIndex = startIndex + 1
			return ""
		if (currentChar == '<'):
			break
		if (endIndex - startIndex > 256):
			break
		# print("<" + currentChar)
		startIndex = startIndex - 1
		currentChar = view.substr(startIndex-1)
	
	if (startIndex == 0):
		return "";
	
	# Step forward till we find the (non-escaped) quotation mark or the end of line/file
	currentChar = view.substr(endIndex)
	while (endIndex < viewSize):
		if (currentChar == '\"' and (endIndex <= 0 or view.substr(endIndex-1) != "\\")):
			break
		if (currentChar == '\n' or currentChar == '\r'):
			return ""
		if (currentChar == '>'):
			break;
		if (endIndex - startIndex > 256):
			break
		# print(">" + currentChar)
		endIndex = endIndex + 1
		currentChar = view.substr(endIndex)
	
	if (endIndex >= viewSize):
		return ""
	
	fileNameRegion = sublime.Region(startIndex, endIndex)
	fileNameLength = endIndex - startIndex
	fileName = view.substr(fileNameRegion)
	# Enable this to escaped quotes into regular quotes in the result
	# fileName = fileName.replace("\\\"", "\"")
	
	return fileName

class PopupTestCommand(sublime_plugin.TextCommand):
	popupItems = [
	"Open String File", 
	"Kill Word", 
	"Pound Replace",
	"Insert Hello World",
	"Taylor Command",
	"View Info",
	"My Google Search",
	"Project Data Test"]
	
	commandItems = [
	"open_string_file", 
	"kill_word", 
	"pound_replace",
	"hello_world",
	"taylor",
	"view_info",
	"my_google_search",
	"project_data_test"]
	
	def popupDone(self, selectedIndex):
		# print("Selected " + self.popupItems[selectedIndex] + "!")
		print("Running command \"" + self.commandItems[selectedIndex] + "\"")
		self.view.run_command(self.commandItems[selectedIndex])
	
	def run(self, edit):
		self.view.show_popup_menu(self.popupItems, self.popupDone)

#'Command' will be removed and all capital letters lowercase
#multiple capital letters results in underscores being added
class HelloWorldCommand(sublime_plugin.TextCommand):
	def run(self, edit):
		self.view.insert(edit, 0, "Hello, World!")
				
class TaylorCommand(sublime_plugin.TextCommand):
	def run(self, edit):
		for selection in self.view.sel():
			actualIndex = selection.begin()
			for cIndex in range(selection.begin(), selection.end()):
				char = self.view.substr(actualIndex)
				print("\'" + char + "\'")
				print(str(ord(char)+1))
				replaceRange = sublime.Region(actualIndex, actualIndex+1)
				newChar = chr(ord(char) + 5)
				newLength = len(newChar)
				self.view.replace(edit, replaceRange, newChar)
				actualIndex += newLength
			self.view.sel().add(sublime.Region(selection.begin(), actualIndex))

class ViewInfoCommand(sublime_plugin.TextCommand):
	def run(self, edit):
		view = self.view
		
		visibleRegion = view.visible_region()
		print("Visible region: [{}, {}]".format(visibleRegion.begin(), visibleRegion.end()))

class ViewPoundReplaceCommand(sublime_plugin.TextCommand):
	def run(self, edit):
		visibleRegion = self.view.visible_region()
		
		for cIndex in range(visibleRegion.begin(), visibleRegion.end()):
			charRegion = sublime.Region(cIndex, cIndex+1)
			currentChar = self.view.substr(charRegion)
			
			if (currentChar != '\n' and currentChar != '\r' and
				currentChar != '\t' and currentChar != ' '):
				self.view.replace(edit, charRegion, '#')

class PoundReplaceCommand(sublime_plugin.TextCommand):
	def run(self, edit):
		
		for region in self.view.sel():
			
			for cIndex in range(region.begin(), region.end()):
				charRegion = sublime.Region(cIndex, cIndex+1)
				currentChar = self.view.substr(charRegion)
				
				if (currentChar != '\n' and currentChar != '\r' and
					currentChar != '\t' and currentChar != ' '):
					self.view.replace(edit, charRegion, '#')

# This is a simple command that deletes the word(s) your cursor is inside
class KillWordCommand(sublime_plugin.TextCommand):
	def run(self, edit):
		for region in self.view.sel():
			word = self.view.word(region)
			self.view.erase(edit, word)

class MyGoogleSearchCommand(sublime_plugin.TextCommand):
	def run(self, edit):
		# print("Running")
		searchString = ""
		for region in self.view.sel():
			if (searchString != ""):
				searchString = searchString + " "
			searchString = searchString + self.view.substr(region)
		
		if (len(searchString) > 0):
			print("My Google Search: Searching for \"" + searchString + "\"")
			searchString = searchString.replace(" ", "+")
			
			webbrowser.open("https://www.google.com/search?q=" + searchString)
		else:
			print("Nothing selected to search for")

def LineIsInclude(view, region):
	matchRegex = "#include"
	matchLength = len(matchRegex)
	lineRegion = view.line(region)
	line = view.substr(lineRegion)
	
	if (len(line) < len(matchRegex) or 
		line[0:matchLength] != matchRegex):
		return False
	
	fileName = GetCString(view, region)
	fileNameLength = len(fileName)
	
	return len(fileName) > 0
	

# This is a simple function that opens the goto window
# with the name of the #include header file that your
# cursor is on already entered into the text box
class OpenStringFileCommand(sublime_plugin.TextCommand):
	
	def want_event(self):
		return True
	
	def run(self, edit, event = None, forcePos = None):
		region = self.view.sel()[0]
		# If we were passed an event we want to look at the point
		# that was clicked on by the mouse instead of selected points
		if (event != None):
			textPos = self.view.window_to_text([event['x'], event['y']])
			region = sublime.Region(textPos, textPos)
		if (forcePos != None):
			region = sublime.Region(forcePos, forcePos)
		
		fileName = GetCString(self.view, region)
		
		if (len(fileName) > 0):
			print("Opening file overlay for filename \"" + fileName + "\"")
			self.view.window().run_command("show_overlay", 
				{"overlay": "goto", "show_files": True, "text": fileName})
	
	# This function determines whether this command shows up in the context menu
	def is_visible(self, event = None):
		region = self.view.sel()[0]
		# If we were passed an event we want to look at the point
		# that was clicked on by the mouse instead of selected points
		if (event != None):
			textPos = self.view.window_to_text([event['x'], event['y']])
			region = sublime.Region(textPos, textPos)
		
		return LineIsInclude(self.view, region)

class IncludeHoverEventListener(sublime_plugin.ViewEventListener):
	
	def OnPopupLinkClicked(self, link):
		self.view.window().run_command("show_overlay", 
			{"overlay": "goto", "show_files": True, "text": link})

	def on_hover(self, point, hover_zone):
		region = sublime.Region(point, point);
		if (hover_zone == sublime.HOVER_TEXT and
			LineIsInclude(self.view, region)):
			# print("Line is #include!")
			fileName = GetCString(self.view, region)
			if (len(fileName) > 0):
				htmlCode = ("<p style=\"padding:0px;margin:0px\">#included file:</p>" + 
					"<a href=\"" + fileName +"\">" + 
					fileName + "</a>?")
				self.view.show_popup(htmlCode, 
					sublime.HIDE_ON_MOUSE_MOVE_AWAY, point, 
					100000, 10000, self.OnPopupLinkClicked)
		
def UpdateZipArchiveFile(zipname, filename, data):
	# generate a temp file
	tmpfd, tmpname = tempfile.mkstemp(dir=os.path.dirname(zipname))
	os.close(tmpfd)

	# create a temp copy of the archive without filename            
	with zipfile.ZipFile(zipname, 'r') as zin:
		with zipfile.ZipFile(tmpname, 'w') as zout:
			zout.comment = zin.comment # preserve the comment
			for item in zin.infolist():
				if item.filename != filename:
					zout.writestr(item, zin.read(item.filename))

	# replace with the temp archive
	os.remove(zipname)
	os.rename(tmpname, zipname)

	# now add filename with its new data
	with zipfile.ZipFile(zipname, mode='a', compression=zipfile.ZIP_DEFLATED) as zf:
		zf.writestr(filename, data)
		
def GetZipArchiveFile(zipname, filename):
	result = ""
	with zipfile.ZipFile(zipname, 'r') as zin:
		for item in zin.infolist():
			if (item.filename == filename):
				result = zin.read(item.filename)
	
	return result
	
		
class ProjectDataTestCommand(sublime_plugin.TextCommand):
	def run(self, edit):
		view = self.view
		window = view.window()
		print("Current Project Data:")
		projectData = window.project_data()
		print(str(projectData))
		
		if (not "settings" in projectData):
			projectData["settings"] = {}
		
		# TODO: Set some settings here to be saved with the project
		
		window.set_project_data(projectData)
		
		current_syntax = view.settings().get("syntax")
		
		searchResult = re.search("Packages[\\/]([\D]+)[\\/]([\D]+)", current_syntax)
		packageName, fileName = searchResult.groups()
		print("Current syntax is \"" + fileName + "\" in " + packageName + ".sublime-package")
		
		windowVars = window.extract_variables()
		print("Window Vars: " + str(windowVars))
		# {
		# 	'platform': 'Windows', 
		# 	'file': 'C:\\Users\\robbitay\\AppData\\Roaming\\Sublime Text 3\\Packages\\User\\tutorial-plugin.py', 
		# 	'project_base_name': 'SublimeTextPlugin', 
		# 	'project_name': 'SublimeTextPlugin.sublime-project', 
		# 	'file_base_name': 'tutorial-plugin', 
		# 	'file_extension': 'py', 
		# 	'project': 'C:\\Users\\robbitay\\Documents\\MyStuff\\Programming\\Tools\\Sublime Text Plugin\\SublimeTextPlugin.sublime-project', 
		# 	'project_path': 'C:\\Users\\robbitay\\Documents\\MyStuff\\Programming\\Tools\\Sublime Text Plugin', 
		# 	'folder': 'C:\\Users\\robbitay\\Documents\\MyStuff\\Programming\\Tools\\Sublime Text Plugin', 
		# 	'packages': 'C:\\Users\\robbitay\\AppData\\Roaming\\Sublime Text 3\\Packages', 
		# 	'file_name': 'tutorial-plugin.py', 
		# 	'project_extension': 'sublime-project', 
		# 	'file_path': 'C:\\Users\\robbitay\\AppData\\Roaming\\Sublime Text 3\\Packages\\User'
		# }
		
		testZipPath = "User/testzip.zip"
		archiveFileName = "tutorial-plugin.py"
		
		absPath = os.path.abspath(testZipPath)
		print("absolute path is \"" + absPath + "\"")
		
		fileContents = GetZipArchiveFile(testZipPath, archiveFileName)
		
		print(str(fileContents))
		
		# fileContents = fileContents + "\nA new line at the end :P"
		
		# UpdateZipArchiveFile(testZipPath, archiveFileName, fileContents)
		
		# file = open("C:/Program Files/Sublime Text 3/Packages/C++.sublime-package", "rb")
		# fileContents = file.read()
		
		# print("File is " + str(len(fileContents)) + " bytes")
		
		# file.close()

A new line at the end :P